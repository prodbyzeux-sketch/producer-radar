import React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import {
  LayoutDashboard,
  Youtube,
  Music2,
  Radar,
  Users,
  MessageSquare,
  Handshake,
  ChevronLeft,
  ChevronRight,
  LogOut
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { signOut } from 'next-auth/react';

const navItems = [
  { path: '/Dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/YouTubeProducers', label: 'YouTube Producers', icon: Youtube },
  { path: '/PlacementProducers', label: 'Placement Producers', icon: Music2 },
  { path: '/Discovery', label: 'Discovery', icon: Radar },
  { path: '/DailyContacts', label: 'Daily Outreach', icon: Users },
  { path: '/Connections', label: 'Connections', icon: Handshake },
  { path: '/MessageGenerator', label: 'Message Generator', icon: MessageSquare },
];

export default function Sidebar({ collapsed, onToggle, mobileOpen, onMobileClose }) {
  const router = useRouter();
  const location = { pathname: router.pathname };

  return (
    <aside className={cn(
      "fixed left-0 top-0 h-screen z-50 flex flex-col transition-all duration-300 ease-in-out",
      "bg-[#18181b] border-r border-[#27272a]",
      // Mobile: full width, slide in/out
      "w-[240px]",
      "translate-x-[-100%] md:translate-x-0",
      mobileOpen && "translate-x-0",
      // Desktop: collapsible
      !mobileOpen && "md:w-[240px]",
      collapsed && "md:w-[68px]"
    )}>
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 h-16 border-b border-[#27272a]">
        <div className="w-8 h-8 rounded-lg bg-[#2563eb] flex items-center justify-center flex-shrink-0">
          <Radar className="w-4 h-4 text-white" />
        </div>
        {!collapsed && (
          <span className="font-semibold text-[15px] text-white tracking-tight whitespace-nowrap">
            Producer Radar
          </span>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-4 px-2 space-y-1">
        {navItems.map(({ path, label, icon: Icon }) => {
          const isActive = location.pathname === path || 
            (path === '/Dashboard' && location.pathname === '/');
          return (
            <Link
              key={path}
              href={path}
              onClick={onMobileClose}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group",
                isActive 
                  ? "bg-[#2563eb]/10 text-[#3b82f6]" 
                  : "text-[#a1a1aa] hover:text-white hover:bg-white/5"
              )}
            >
              <Icon className={cn("w-[18px] h-[18px] flex-shrink-0", isActive && "text-[#3b82f6]")} />
              {!collapsed && (
                <span className="text-[13px] font-medium whitespace-nowrap">{label}</span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Logout */}
      <button
        onClick={() => signOut({ callbackUrl: '/login' })}
        className={cn(
          "flex items-center gap-3 px-3 py-2.5 mx-2 mb-1 rounded-lg transition-colors text-[#71717a] hover:text-red-400 hover:bg-red-400/5"
        )}
      >
        <LogOut className="w-[18px] h-[18px] flex-shrink-0" />
        {!collapsed && <span className="text-[13px] font-medium">Logout</span>}
      </button>

      {/* Collapse toggle */}
      <button
        onClick={onToggle}
        className="flex items-center justify-center h-12 border-t border-[#27272a] text-[#71717a] hover:text-white transition-colors"
      >
        {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
      </button>
    </aside>
  );
}